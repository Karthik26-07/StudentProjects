<?php include('../Admin/navbar.php'); ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <style>
            
               body {
                background-image: url("Dairy.jpg");
                background-size: cover;
                background-repeat: no-repeat;
                /*background-position: center;*/
                position: relative;
                /*z-index: 2;*/
                /*overflow: hidden;*/


            }
             .index{
                width: 35%;
                left:30%;
                /*backgroundcolor: */

            }
        </style>
        <title>Home Page</title>
    </head>
    <body>
        <form class=" body my-5 text-center" method="post" >

            
        </form>
        
    </body>
</html>
