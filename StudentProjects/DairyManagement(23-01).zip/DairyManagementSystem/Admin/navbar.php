<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <title>Navbar</title>
      
    </head>
    <body>
        <div id="navbar">
            <nav class="navbar navbar-light" style="background-color: #a041e8">
                <span class="navbar-brand mb-0 h1 text-white">Dairy Management System</span>
                <ul class="nav nav-pills">
                    <li class="nav-item dropdown px-3  ">


                        <a class="nav-link text-white btn" href="../Staff/AddStaff.php">Staff</a>


                    </li>
                    <li class="nav-item dropdown px-1 ">
                        <a class="nav-link text-white btn " id="faculty" href="../Consumer/AddConsumer.php">Consumer</a>
                    </li>
                    <li class="nav-item dropdown  px-1 ">


                        <a class="nav-link text-white btn" id="Attendance" href="../Distributor/AddDistributor.php">Distributor</a>


                    </li>
                    <li class="nav-item dropdown px-1">


                        <a class="nav-link text-white btn " id="Attendance" href="../CoOperative/CoOperative.php">Co-Operative</a>


                    </li>
                    <li class="nav-item dropdown px-1">


                        <a class="nav-link text-white btn " id="Attendance" href="../ConsumerMaping/consumerMapping.php">Consumer-mapping</a>


                    </li>
                    <li class="nav-item dropdown px-1">


                        <a class="nav-link text-white btn " id="Attendance" href="../DistributorMapping/DistributorMapping.php">Distributor-Mapping</a>


                    </li>

                    <li class="nav-item dropdown px-1 ">


                        <a class="nav-link bg-white" href="../Admin/AdminLogin.php">Logout</a>


                    </li>
                </ul>
            </nav>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--        <script>
            window.onscroll = function () {
                myFunction()
            };

            var navbar = document.getElementById("navbar");
            var sticky = navbar.offsetTop;

            function myFunction() {
                if (window.pageYOffset >= sticky) {
                    navbar.classList.add("sticky")
                } else {
                    navbar.classList.remove("sticky");
                }
            }
        </script>-->
    </body>
</html>
