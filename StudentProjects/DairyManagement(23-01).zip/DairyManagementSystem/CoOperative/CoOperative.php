<?php
include('../Admin/navbar.php');
include('../Database_Connection/Dbconnect.php');
$nameErr1 = $phoneErr1 = "";

if (isset($_POST['Add'])) {

    if (empty($_POST['coname'])) {
        $nameErr1 = "Co-Operative Name is Required";
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST["coname"])) {
        $nameErr1 = "Only alphabets and white space are allowed";
    } else if (empty($_POST['NumberOfStaff'])) {
        $phoneErr1 = "Number of staff is required";
    } else if (!preg_match("/^[0-9]*$/", $_POST["NumberOfStaff"])) {
        $phoneErr1 = "Only numeric value is allowed.";
    } else {
        $CoName = $_POST['coname'];
        $NoStaff = $_POST['NumberOfStaff'];
        $Query = "insert into co_operative(Co_Name,Co_Staff) values('$CoName','$NoStaff')";
        if ($con->query($Query) === TRUE) {
            echo "<script>alert('Succesfully Added');</script>";
            echo "<script>window.location.href='../CoOperative/CoOperative.php'</script>";
        } else {
            echo "Error: " . $Query . "<br>" . $con->error;
        }
    }
}
?>
<?php
$sql = "select * from co_operative";
$result = mysqli_query($con, $sql);
$i = 1;
$row = [];
if ($result->num_rows > 0) {

    $row = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<?php
if (isset($_POST['update'])) {
    include('../Database_Connection/Dbconnect.php');

    $id = $_POST['ID'];

    $editCoOperative_name = $_POST ['editconame'];
    $editNoofstaffs = $_POST['editnoofstaff'];

    $Update = "update co_operative set Co_Name='$editCoOperative_name',Co_Staff='$editNoofstaffs' where Co_Id='$id' ";
    if ($con->query($Update) === TRUE) {
        echo "<script>alert('Succesfullly Updated');</script>";
        echo "<script>window.location.href='../CoOperative/CoOperative.php'</script>";
    } else {
        echo "Error: " . $Update . "<br>" . $con->error;
    }
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <title>Distributor Registration</title>
        <style>
            .index{
                margin-left: 10%;

            }
            .margin{
                margin-left: 21%;
            }
            .index{
                width: 35%;
                left:7%;

            }
            .margin1{
                margin-left: 20%;
            }
            .margin2{
                margin-left:12%; 
            }
            .error {color: #FF0001;}
            .margin3{
                margin-left: 62%;
            }
        </style>
    </head>
    <body>
        <div class="form-row">
            <div class="form-group  col-md-6 " >    


                <!--<button class="btn my-2 btn-1g text-white" style="background-color: #8f02fa; width:10%; margin-left: 5%;" name="submit"type="submit">Back</button>-->
                <form class=" my-5 card" method="post" style="width:70%; margin-left: 5%;" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div  class="form-group"style="margin-left:10%;">
                        <div class="my-4 " style="margin-left:20%;">
                            <h3><b>Co-Operative</b></h3>
                        </div>

                        <div class="form-inline ">
                            <div class="form-group mb-2">
                                <b> C.O Name:</b>

                            </div>
                            <div class="form-group mx-sm-0 mb-2">
                                <input type="text" class="form-control margin" id="coname" name="coname" placeholder="Co-Operative Name">

                            </div>
                        </div>
                        <div class="form-inline">
                            <div class="form-group mb-2">
                                <b>  No Of Staff:</b>

                            </div>
                            <div class="form-group mx-sm-2 mb-2">
                                <input type="number" class="form-control margin2 " id="NumberOfStaff" name="NumberOfStaff" placeholder="Number Of Staff">

                            </div>
                        </div>




                        <span class="error"> <?php echo $nameErr1; ?> </span>
                        <span class="error"> <?php echo $phoneErr1; ?> </span>

                        <br>


                        <button class="btn  my-3 btn-1g text-white" style="background-color: #8f02fa; width: 83%; " name="Add" type="submit">Add</button>
                    </div>
                </form>
            </div>

            <div class="form-group col-md-6">


                <form class=" card stud   shadow-lg p-3  mb-5 bg-white rounded body"style="width: 100%;
                      left: 0%; margin-top: 7%;" >
                    <div class="form-group">
                        <table class="table  table-striped table-hover ">
                            <thead>
                                <tr>
                                    <th scope=col>S.NO</th>

                                    <th scope=col>Co-Operative name</th>

                                    <th scope=col>NO Of Staff</th>

                                    <th scope=col>Action</th>



                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (!empty($row)) {
                                    foreach ($row as $row) {
                                        ?>   <tr>   
                                            <td><?php echo $i++ ?> </td>
                                            <td><?php echo $row['Co_Name']; ?> </td>
                                            <td><?php echo $row['Co_Staff']; ?></td>
                                            <td id="<?= $row['Co_Id'] ?>"><?php echo '   <button type="button"  onclick="Delete( ' . $row['Co_Id'] . ');" class="btn btn-danger" >Delete</button>'; ?>
                                            <?php echo '   <button type="button"  onclick="Update(' . $row['Co_Id'] . ');"  data-toggle="modal" data-target="#editmodal" class="btn btn-success" >Update</button>'; ?></td>



                                                <?php
                                            }
                                        }
                                        ?>
                                </tr></tbody></table></div></form>
            </div></div>

        <!--##############################################################################################################################-->
        <!--Update Modal-->
        <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="">
            <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="my-1 " style="margin-left:20%;">
                                <h3><b>Update Co-Operative</b></h3>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div style="margin-top:5%">
                            <div class="form-inline  ">
                                <div class="form-group mb-2 px-5">
                                    <b> Co-Operative Name:</b>

                                </div>
                                <div class="form-group mx-sm-0 mb-2">
                                    <input type="text" class="form-control " style="margin-left:0%;" id="editconame" name="editconame" placeholder="Co_operative Name"required>

                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  No of staff:</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2">
                                    <input type="text" class="form-control  " id="editnoofstaff" style="margin-left:29%;" name="editnoofstaff" placeholder="No Of Staff"required>

                                </div>
                            </div>

                            <input type="text" name="ID" id="ID" hidden>


                            <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 35%; margin-top: 3%" name="update" type="submit">Update</button>
                        </div></div></div>
            </div>

        </form>
        <!--#################################-->




        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>

        <script type="text/javascript"  >

            function Delete(id) {
                if (confirm('Are you sure?')) {
                    $.ajax({
                        type: "POST",
                        url: "../CoOperative/DeleteCoOperative.php",

                        data: {id: id},

                        timeout: 10000,
                        success: function () {
                            document.location.reload()

                        }
                    });
                } else {
                    // Do nothing!

                }
            }


        </script>
        <script>

            function Update(id) {
                $.ajax({
                    type: "POST",

                    url: "../CoOperative/UpdateCoOperative.php",

                    data: {id: id},
                    datatype: 'json',
                    timeout: 10000,
                    success: function (data) {
//alert(data);
                        var arr = new Array();
                        arr = JSON.parse(data);
                        $('#ID').val(arr.Co_Id);
                        $('#editconame').val(arr.Co_Name);
                        $('#editnoofstaff').val(arr.Co_Staff);


                    }
                });
            }
        </script>
    </body>
</html>