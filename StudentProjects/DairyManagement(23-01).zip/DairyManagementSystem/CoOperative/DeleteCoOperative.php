<?php

include('../Database_Connection/Dbconnect.php');

$id = $_POST['id'];
echo $id;
$delete = mysqli_query($con, "DELETE FROM co_operative WHERE Co_Id='$id'");
?>