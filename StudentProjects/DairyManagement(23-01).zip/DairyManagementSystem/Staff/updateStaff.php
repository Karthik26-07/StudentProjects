<?php
include('../Database_Connection/Dbconnect.php');

$id = $_POST['id'];
$sql1 = "SELECT staff.*,
  co_operative.Co_Name
  FROM co_operative
  JOIN staff 
  ON
  co_operative.Co_Id=staff.Staff_CO_Id where Staff_Id='$id'";
$result1 = mysqli_query($con, $sql1);
//$Data=[];
//while($data= mysqli_fetch_assoc($result1)){
//   $row=array(
//       "id" => $data['Staff_Id']
//   );
//    array_push($Data, $row);
//}
$Data= mysqli_fetch_assoc($result1);
echo json_encode($Data);
?>
 