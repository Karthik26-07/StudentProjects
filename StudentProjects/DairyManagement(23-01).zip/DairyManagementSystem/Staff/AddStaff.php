<?php
include('../Admin/navbar.php');
include('../Database_Connection/Dbconnect.php');
$nameErr1 = $phoneErr1 = $coErr = "";
if (isset($_POST['Add'])) {

    if (empty($_POST['staffname'])) {
        $nameErr1 = "Staff Name is Required";
    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST["staffname"])) {
        $nameErr1 = "Only alphabets and white space are allowed"; 
    } else if (empty($_POST['staffphone'])) {
        $phoneErr1 = "Staff Phone number is  is required";
    } else if (!preg_match("/^[0-9]*$/", $_POST["staffphone"])) {
        $phoneErr1 = "Only numeric value is allowed.";
    } else if (strlen($_POST["staffphone"]) != 10) {
        $phoneErr1 = "Mobile no must contain 10 digits.";
    } else if (empty($_POST['coname'])) {
        $coErr = "Please select the co-operative  name";
    } else {

        $StaffName = $_POST['staffname'];
        $StaffPhone = $_POST['staffphone'];
        $Gender = $_POST['groupOfDefaultRadios'];
        $COName = $_POST['coname'];

        $Query = "insert into staff(Staff_Name,Staff_Gender,Staff_Phone,Staff_CO_Id) values('$StaffName','$Gender','$StaffPhone','$COName')";
        if ($con->query($Query) === TRUE) {
            echo "<script>alert('Succesfully Added');</script>";
            echo "<script>window.location.href='../Staff/AddStaff.php'</script>";
        } else {
            echo "Error: " . $Query . "<br>" . $con->error;
        }
    }
}
?>

<?php
if (isset($_POST['Update'])) {

    $ID = $_POST['ID'];

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $coname = $_POST['coName'];

    $gender = $_POST['gender'];
    $Update = "update staff set Staff_Name='$name',Staff_Gender='$gender',Staff_Phone='$phone',Staff_CO_Id='$coname' where Staff_Id='$ID' ";
    if ($con->query($Update) === TRUE) {
        echo "<script>alert('Succesfully Updated');</script>";
        echo "<script>window.location.href='../Staff/AddStaff.php'</script>";
    } else {
        echo "Error: " . $Update . "<br>" . $con->error;
    }
}
?>
<?php
include('../Database_Connection/Dbconnect.php');

$sql1 = "SELECT staff.*,
  co_operative.Co_Name
  FROM co_operative
  JOIN staff 
  ON
  co_operative.Co_Id=staff.Staff_CO_Id";
$result1 = mysqli_query($con, $sql1);
$i = 1;
$rows = [];
if ($result1->num_rows > 0) {

    $rows = $result1->fetch_all(MYSQLI_ASSOC);
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <title>Distributor Registration</title>
        <style>
            .margin{
                margin-left: 30%;
            }
            .index{
                width: 35%;
                left:2%;

            }
            .margin1{
                margin-left: 20%;
            }
            .margin2{
                margin-left:12%; 
            }
            .error {color: #FF0001;}
            .margin3{
                margin-left: 62%;
            }
        </style>
    </head>
    <body>
        <div class="form-row">
            <div class="form-group  col-md-4 " >    
                <!--<button class="btn my-2 btn-1g text-white" style="background-color: #8f02fa; width:10%; margin-left: 5%;" name="submit"type="submit">Back</button>-->
                <form class=" card index my-5  shadow-lg p-3 mb-5 bg-white rounded body" style="width:110%;" method="post" 
                      action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="my-4 " style="margin-left:30%;">
                        <h3><b>Add Staff</b></h3>
                    </div>


                    <div class="form-inline ">
                        <div class="form-group mb-2">
                            <b> Staff Name:</b>

                        </div>
                        <div class="form-group mx-sm-0 mb-2">
                            <input type="text" class="form-control margin" id="staffname" name="staffname" placeholder="Name">

                        </div>
                    </div>
                    <div class="form-inline">
                        <div class="form-group mb-2">
                            <b>  Phone Number:</b>

                        </div>
                        <div class="form-group mx-sm-2 mb-2">
                            <input type="text" class="form-control margin2 " id="staffphone" name="staffphone" placeholder="Phonenumber">

                        </div>
                    </div>
                    <div class="form-inline">
                        <div class="form-group mb-2">
                            <b> Gender:</b>

                        </div>
                        <div class="form-group margin1">
                            <!-- Group of default radios - option 1 -->
                            <div class="custom-control custom-radio px-4">
                                <input type="radio" class="custom-control-input" id="defaultGroupExample1" value="Male" name="groupOfDefaultRadios">
                                <label class="custom-control-label" for="defaultGroupExample1">Male</label>
                            </div><br>

                        </div>
                        <!-- Group of default radios - option 2 -->
                        <div class="custom-control custom-radio px-4">
                            <input type="radio" class="custom-control-input" id="defaultGroupExample2" value="Female" name="groupOfDefaultRadios">
                            <label class="custom-control-label" for="defaultGroupExample2">Female</label>
                        </div>

                        <!-- Group of default radios - option 3 -->
                        <div class="custom-control custom-radio">
                            <input type="radio" class="custom-control-input" id="defaultGroupExample3" value="Other" name="groupOfDefaultRadios" checked>
                            <label class="custom-control-label" for="defaultGroupExample3">Other</label>
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="form-group mb-2">
                            <b>Co- Names:</b> 
                            <div class="form-group mx-sm-5 mb-2 px-3 margin3">
                                <select class="my-3 " name="coname" id='coname'selected="selected">
                                    <option value="" selected="selected" >--- Select name---</option>
                                    <?php
                                    $sql = "select * From co_operative";
                                    $result = mysqli_query($con, $sql);
                                    while ($row_ah = mysqli_fetch_assoc($result)) {
                                        ?>
                                        <option value="<?php echo $row_ah['Co_Id']; ?> " id="namesid" name="namesid"><?php echo $row_ah['Co_Name']; ?></option>
                                    <?php } ?>
                                </select>

                            </div>
                        </div>
                    </div>

                    <span class="error"> <?php echo $nameErr1; ?> </span>
                    <span class="error"> <?php echo $phoneErr1; ?> </span>
                    <span class="error"> <?php echo $coErr; ?> </span>



                    <button class="btn  my-3 btn-1g text-white" style="background-color: #8f02fa" name="Add" type="submit">Add</button>

                </form>
            </div>

            <div class="form-group col-md-4">

                <form class=" card stud   shadow-lg p-3  mb-5 bg-white rounded body"
                      style=" margin-top: 12%; width: 190%; margin-left: 10%" >
                    <div class="form-group">
                        <table class="table  table-striped table-hover ">
                            <thead>
                                <tr>
                                    <th scope=col>S.NO</th>

                                    <th scope=col>Staff name</th>

                                    <th scope=col>Phone Number</th>
                                    <th scope=col>Gender</th>
                                    <th scope=col>Co-Operative Name</th>
                                    <th scope=col>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (!empty($rows)) {
                                    foreach ($rows as $row) {
                                        ?>   <tr>   
                                            <td><?php echo $i++ ?> </td>
                                            <td><?php echo $row['Staff_Name']; ?> </td>
                                            <td><?php echo $row['Staff_Phone']; ?></td>
                                            <td><?php echo $row['Staff_Gender']; ?></td>
                                            <td><?php echo $row['Co_Name']; ?></td>

                                            <td id="<?= $row['Staff_Id'] ?>"><?php echo '   <button type="button"  onclick="Delete( ' . $row['Staff_Id'] . ');" class="btn btn-danger" >Delete</button>'; ?>
                                           <?php echo '   <button type="button"  onclick="Update(' . $row['Staff_Id'] . ');" data-toggle="modal" data-target="#editmodal" class="btn btn-success">Update</button>'; ?></td>





                                                <?php
                                            }
                                        }
                                        ?>
                                </tr></tbody></table></div></form>







            </div>
            <!--##################################################################--Edit Modal--##########################################-->
            <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="">
                <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <div class="my-1 " style="margin-left:30%;">
                                    <h3><b>Edit Staff</b></h3>
                                    <span id="idHolder" name="ids"></span>

                                </div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div style="margin-top:5%">
                                <input type="text" class="form-control margin" id="ID" name="ID" placeholder="Name" hidden>
                                <div class="form-inline">
                                    <div class="form-group mb-2 px-5">
                                        <b>Staff name:</b> 
                                        <div class="form-group mx-sm-5 mb-2 " >
                                            <input type="text" class="form-control " style="margin-left:28%;"    id="name" name="name" placeholder="Staff Name"required>


                                        </div>
                                    </div>
                                </div>
                                <div class="form-inline">
                                    <div class="form-group mb-2 px-5">
                                        <b> Phone Number:</b> 
                                        <div class="form-group mx-sm-5 mb-2 px-3">
                                            <input type="text" class="form-control " style="margin-left:3%;"    id="phone" name="phone" placeholder="Staff Phone Number"required>


                                        </div>
                                    </div>
                                </div>          

                                <div class="form-inline">
                                    <div class="form-group mb-2 px-5">
                                        <b>Co-operative Name:</b> 
                                        <div class="form-group mx-sm-5 mb-2 " >
                                            <select class=" " name="coName" id='coName'selected="selected" style="margin-left:0%;" required>
                                                <option  selected="selected" disabled>--- Select Co-Operative---</option>
                                                <?php
                                                $sqla = "select * From co_operative";
                                                $resulta = mysqli_query($con, $sqla);
                                                while ($row_ah = mysqli_fetch_assoc($resulta)) {
                                                    ?>
                                                    <option value="<?php echo $row_ah['Co_Id']; ?> " id="namesid" name="namesid"><?php echo $row_ah['Co_Name']; ?></option>
                                                <?php } ?>
                                            </select>

                                        </div>
                                    </div>
                                </div>     



                                <div class="form-inline">
                                    <div class="form-group mb-2 px-5">
                                        <b>  Gender   :</b>

                                    </div>
                                    <div class="form-group mx-sm-2 mb-2"  >
                                        <input type="text" class="form-control " style="margin-left:33%;"    id="gender" name="gender" placeholder="Gender"required>

                                    </div>
                                </div>



                                <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 30%; margin-top: 3%" name="Update" type="submit">Update</button>
                            </div></div></div>
                </div>

            </form>
            <!--########################################################################################################################-->

            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
            <script src="https://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
            <script type="text/javascript"  >

                function Delete(id) {
                    if (confirm('Are you sure?')) {
                        $.ajax({
                            type: "POST",
                            url: "../Staff/deleteStaff.php",

                            data: {id: id},

                            timeout: 10000,
                            success: function () {
                                document.location.reload()
                            }
                        });
                    } else {
                        // Do nothing!

                    }
                }


            </script>
            <script>
                function Update(id) {
                    $.ajax({
                        type: "POST",
                        url: "../Staff/updateStaff.php",

                        data: {id: id},
                        datatype: 'json',
                        timeout: 10000,
                        success: function (data) {
//                            alert(data);
                            var arr = new Array();
                            arr = JSON.parse(data);
                            $('#ID').val(arr.Staff_Id);
                            $('#name').val(arr.Staff_Name);
                            $('#phone').val(arr.Staff_Phone);
                            $('#coName').val(arr.Co_Name);
                            $('#gender').val(arr.Staff_Gender);



                        }
                    });
                }

            </script> 

    </body>
</html>