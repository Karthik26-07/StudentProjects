-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2023 at 08:18 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dairymanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `consumer`
--

CREATE TABLE `consumer` (
  `Consumer_ID` int(255) UNSIGNED NOT NULL,
  `Consumer_Name` varchar(50) NOT NULL,
  `Consumer_phone` varchar(10) NOT NULL,
  `Consumer_Address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `consumer`
--

INSERT INTO `consumer` (`Consumer_ID`, `Consumer_Name`, `Consumer_phone`, `Consumer_Address`) VALUES
(10, 'Charan', '1234567890', 'Bondel');

-- --------------------------------------------------------

--
-- Table structure for table `co_operative`
--

CREATE TABLE `co_operative` (
  `Co_Id` int(200) UNSIGNED NOT NULL,
  `Co_Name` varchar(50) NOT NULL,
  `Co_Staff` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `co_operative`
--

INSERT INTO `co_operative` (`Co_Id`, `Co_Name`, `Co_Staff`) VALUES
(4, 'Shodan', '10'),
(18, 'Karthik', '10');

-- --------------------------------------------------------

--
-- Table structure for table `distributor`
--

CREATE TABLE `distributor` (
  `Distributor_ID` int(50) UNSIGNED NOT NULL,
  `Distributor_Name` varchar(50) NOT NULL,
  `Distributor_Phone` varchar(10) NOT NULL,
  `Distributor_Address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `distributor`
--

INSERT INTO `distributor` (`Distributor_ID`, `Distributor_Name`, `Distributor_Phone`, `Distributor_Address`) VALUES
(17, 'Karthik', '1234567890', 'Bondel'),
(18, 'kiran', '1234567890', '123'),
(19, 'shlus', '1234567890', '123'),
(20, 'karan', '1234567890', 'Bondel');

-- --------------------------------------------------------

--
-- Table structure for table `provides`
--

CREATE TABLE `provides` (
  `Provides_ID` int(255) UNSIGNED NOT NULL,
  `Pr_quantity` varchar(50) NOT NULL,
  `Pr_MilkType` varchar(50) NOT NULL,
  `Pr_CoOperative` varchar(50) NOT NULL,
  `Pr_Distributor` varchar(50) NOT NULL,
  `Pr_Date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provides`
--

INSERT INTO `provides` (`Provides_ID`, `Pr_quantity`, `Pr_MilkType`, `Pr_CoOperative`, `Pr_Distributor`, `Pr_Date`) VALUES
(1, '46', 'Orange', '2 ', '2 ', '0000-00-00'),
(2, 'vsv', 'Orange', '2 ', '2 ', '2023-01-14'),
(3, '46', 'Orange', '2 ', '3 ', '2023-01-14'),
(4, '463', 'Blue', '3 ', '14 ', '2023-01-14'),
(5, '346', 'Blue', '2 ', '14 ', '2023-01-14'),
(6, '46', 'Blue', '1 ', '14 ', '2023-01-14'),
(8, '46', 'Orange', '4 ', '17 ', '2023-01-14'),
(9, '', '', '', '', '2023-01-16'),
(10, '80', 'Blue', '18 ', '17 ', '2023-01-16'),
(14, '2', 'Blue', '4 ', '18 ', '2023-01-23');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_Id` int(255) UNSIGNED NOT NULL,
  `Staff_Name` varchar(50) NOT NULL,
  `Staff_Gender` varchar(10) NOT NULL,
  `Staff_Phone` varchar(10) NOT NULL,
  `Staff_CO_Id` int(10) NOT NULL,
  `is_active` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_Id`, `Staff_Name`, `Staff_Gender`, `Staff_Phone`, `Staff_CO_Id`, `is_active`) VALUES
(12, 'kiranqw', 'Female', '1234567890', 0, NULL),
(13, 'wefw', 'Male', '1234567890', 0, NULL),
(14, 'Kiran', 'Female', '1234567890', 0, NULL),
(15, 'kiran', 'Female', '1234567890', 0, NULL),
(16, 'wefwfgnfgn', 'Female', '1234567890', 0, NULL),
(17, 'Kiran', 'Female', '1234567890', 0, NULL),
(18, 'abcd', 'Male', '1234567890', 0, NULL),
(19, 'wefw', 'Male', '1234567890', 0, NULL),
(20, 'kiran', 'Female', '1234567890', 0, NULL),
(21, 'wefw', 'Female', '1234567890', 0, NULL),
(22, 'wefw', 'Female', '1234567890', 18, NULL),
(26, 'Preran', 'Male', '7338357926', 18, 1);

--
-- Triggers `staff`
--
DELIMITER $$
CREATE TRIGGER `staff_insert_trigger` BEFORE INSERT ON `staff` FOR EACH ROW set NEW.is_active=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE `supplies` (
  `Supplies_ID` int(255) UNSIGNED NOT NULL,
  `Sup_Quantity` varchar(50) NOT NULL,
  `Sup_Date` date NOT NULL DEFAULT current_timestamp(),
  `Sup_MilkType` varchar(50) NOT NULL,
  `Sup_Consumer` varchar(50) NOT NULL,
  `Sup_Distributor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplies`
--

INSERT INTO `supplies` (`Supplies_ID`, `Sup_Quantity`, `Sup_Date`, `Sup_MilkType`, `Sup_Consumer`, `Sup_Distributor`) VALUES
(23, '90', '2023-01-16', 'Orange', '9 ', '18 '),
(24, '80', '2023-01-16', 'Blue', '6 ', '17 '),
(25, '2', '2023-01-23', 'Blue', '10 ', '17 ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consumer`
--
ALTER TABLE `consumer`
  ADD PRIMARY KEY (`Consumer_ID`);

--
-- Indexes for table `co_operative`
--
ALTER TABLE `co_operative`
  ADD PRIMARY KEY (`Co_Id`);

--
-- Indexes for table `distributor`
--
ALTER TABLE `distributor`
  ADD PRIMARY KEY (`Distributor_ID`);

--
-- Indexes for table `provides`
--
ALTER TABLE `provides`
  ADD PRIMARY KEY (`Provides_ID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_Id`);

--
-- Indexes for table `supplies`
--
ALTER TABLE `supplies`
  ADD PRIMARY KEY (`Supplies_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consumer`
--
ALTER TABLE `consumer`
  MODIFY `Consumer_ID` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `co_operative`
--
ALTER TABLE `co_operative`
  MODIFY `Co_Id` int(200) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `distributor`
--
ALTER TABLE `distributor`
  MODIFY `Distributor_ID` int(50) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `provides`
--
ALTER TABLE `provides`
  MODIFY `Provides_ID` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_Id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `supplies`
--
ALTER TABLE `supplies`
  MODIFY `Supplies_ID` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
