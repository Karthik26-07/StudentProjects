<?php

include('../Database_Connection/Dbconnect.php');

$id = $_POST['id'];
echo $id;
$delete = mysqli_query($con, "DELETE FROM supplies WHERE Supplies_ID='$id'");
?>