<?php
include('../Database_Connection/Dbconnect.php');
$id = $_POST['id'];

$sqli = "SELECT consumer.Consumer_Name,
distributor.Distributor_Name,
supplies.*
FROM supplies
JOIN
distributor ON
distributor.Distributor_ID=supplies.Sup_Distributor
JOIN
 consumer ON
consumer.Consumer_ID=supplies.Sup_Consumer
where Supplies_ID='$id'";
$data = mysqli_query($con, $sqli);
$result=mysqli_fetch_assoc($data);
echo json_encode($result);