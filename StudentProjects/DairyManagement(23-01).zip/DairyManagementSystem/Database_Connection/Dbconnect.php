<?php

$con = mysqli_connect('localhost', 'root', '', 'dairymanagement');

if ($con->connect_error) {
    die("Connection failure: "
            . $con > connect_error);
} else {

}
?>
