<?php
include('../Admin/navbar.php');
include('../Database_Connection/Dbconnect.php');
?>
<?php
if (isset($_POST['Add'])) {
    $Distributor = $_POST['disname'];
    $CoOperative = $_POST['coname'];
    $MilkType = $_POST['milktype'];
    $Quantity = $_POST['quantity'];
    $Query = "insert into provides(Pr_quantity,Pr_MilkType,Pr_CoOperative,Pr_Distributor) values('$Quantity','$MilkType','$CoOperative','$Distributor')";
    if ($con->query($Query) === TRUE) {
        echo "<script>alert('Succesfully Added');</script>";
        echo "<script>window.location.href='../DistributorMapping/DistributorMapping.php'</script>";
    } else {
        echo "Error: " . $Query . "<br>" . $con->error;
    }
}
?>
<?php
$sqli = "SELECT co_operative.Co_Name,
distributor.*,
provides.*
FROM provides
JOIN
distributor ON
distributor.Distributor_ID=provides.Pr_Distributor
JOIN
 co_operative ON
co_operative.Co_Id=provides.Pr_CoOperative";
$data = mysqli_query($con, $sqli);


$i = 1;
$row = [];
if ($data->num_rows > 0) {

    $row = $data->fetch_all(MYSQLI_ASSOC);
}
?> 
<?php
if (isset($_POST['Update'])) {
    $id = $_POST['ID'];
    $coname = $_POST['editconame'];
    $disname = $_POST['editdisname'];
    $milktype = $_POST['editmilktype'];
    $quantity = $_POST['editquantity'];
    $Update = "update provides set Pr_Distributor='$disname',Pr_CoOperative='$coname',Pr_quantity='$quantity',Pr_MilkType='$milktype' where Provides_ID='$id' ";

    if ($con->query($Update) === TRUE) {
        echo "<script>alert('Succesfully Updated');</script>";
        echo "<script>window.location.href='../ConsumerMaping/consumerMapping.php'</script>";
    } else {
        echo "Error: " . $Update . "<br>" . $con->error;
    }
}
?>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <title>Distributor Registration</title>
        <style>

            .index{
                width: 35%;
                left:7%;

            }


            .error {color: #FF0001;}
            .button{
                margin-left: 10%;
                background-color: #8f02fa; 
                width: 10%;
            }
        </style>
    </head>
    <body>

        <!--##########################################insert modal######################-->

        <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="modal fade" id="Distributor" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="my-1 " style="margin-left:20%;">
                                <h3><b>Distributor Mapping</b></h3>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div style="margin-top:5%">
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Co-operative Name:</b> 
                                    <div class="form-group mx-sm-5 mb-2 " >
                                        <select class=" " name="coname" id='coname'selected="selected" style="margin-left:0%;" required>
                                            <option value="" selected="selected" disabled>--- Select Co-Operative---</option>
                                            <?php
                                            $sql = "select * From co_operative";
                                            $result = mysqli_query($con, $sql);
                                            while ($row_ah = mysqli_fetch_assoc($result)) {
                                                ?>
                                                <option value="<?php echo $row_ah['Co_Id']; ?> " id="namesid" name="namesid"><?php echo $row_ah['Co_Name']; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Distributor Name:</b> 
                                    <div class="form-group mx-sm-5 mb-2 px-3">
                                        <select class=" " name="disname" id='disname'selected="selected" required >
                                            <option value="" selected="selected" disabled >--- Select Distributor---</option>
                                            <?php
                                            $sql1 = "select * From distributor";
                                            $result1 = mysqli_query($con, $sql1);
                                            while ($row_ah1 = mysqli_fetch_assoc($result1)) {
                                                ?>
                                                <option value="<?php echo $row_ah1['Distributor_ID']; ?> " id="namesid" name="namesid"><?php echo $row_ah1['Distributor_Name']; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                </div>
                            </div>          

                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Milk Type:</b> 
                                    <div class="form-group mx-sm-5 mb-2 px-3 margin3">
                                        <select class=" " name="milktype" id='milktype'selected="selected" style="margin-left:32%; " required>
                                            <option value="" selected="selected" disabled>--- Select MilkType---</option>     
                                            <option value="Orange"  >Orange</option> 
                                            <option value="Blue"  >Blue</option>  
                                            <option value="Green"  >Green</option>     



                                        </select>

                                    </div>
                                </div>
                            </div>          



                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Quantity   :</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2"  >
                                    <input type="text" class="form-control " style="margin-left:33%;"    id="quantity" name="quantity" placeholder="Quantity"required>

                                </div>
                            </div>



                            <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 30%; margin-top: 3%" name="Add" type="submit">Add</button>
                        </div></div></div>
            </div>

        </form>
        <!--##################################################################################-->

        <button type="button" class="btn btn-success button" data-toggle="modal" data-target="#Distributor">

            <i class="fa-home"></i>  Add
        </button>
        <form class=" card stud   shadow-lg p-3  mb-5 bg-white rounded body"style="width: 85%;
              left: 8%;">
            <div class="form-group">
                <table class="table  table-striped table-hover ">
                    <thead>
                        <tr>
                            <th scope=col>S.NO</th>



                            <th scope=col>Co Operative Name</th>
                            <th scope=col>Distributor Name</th>
                            <th scope=col>Distributor Address</th>
                            <th scope=col>Milk Type</th>
                            <th scope=col>Quantity</th>
                            <th scope=col>Date</th>
                            <th scope=col>Action</th>





                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        if (!empty($row)) {
                            foreach ($row as $row) {
                                ?> 

                                <tr>


                                    <td><?php echo $i++ ?> </td>

                                    <td><?php echo $row['Co_Name']; ?> </td>
                                    <td><?php echo $row['Distributor_Name']; ?> </td>
                                    <td><?php echo $row['Distributor_Address']; ?> </td>
                                    <td><?php echo $row['Pr_MilkType']; ?> </td>
                                    <td><?php echo $row['Pr_quantity']; ?></td>
                                    <td><?php echo $row['Pr_Date']; ?> </td>
                                    <td id="<?= $row['Provides_ID'] ?>"><?php echo '   <button type="button"  onclick="Delete( ' . $row['Provides_ID'] . ');" class="btn btn-danger" >Delete</button>'; ?>
                                        <?php echo '   <button type="button"  onclick="Update( ' . $row['Provides_ID'] . ');" data-toggle="modal" data-target="#editmodal" id="update" class="  btn btn-success" >Update</button>'; ?></td>




                                </tr>

                                <?php
                            }
                        }
                        ?>
                    </tbody></table></div></form>
        <!--########################################### Edit Modal#################################-->
        <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="">
            <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="my-1 " style="margin-left:20%;">
                                <h3><b> Edit Distributor Mapping</b></h3>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div style="margin-top:5%">
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Co-operative Name:</b> 
                                    <div class="form-group mx-sm-5 mb-2 " >
                                        <select class=" " name="editconame" id='editconame'selected="selected" style="margin-left:0%;" required>
                                            <option value="" selected="selected" disabled>--- Select Co-Operative---</option>
                                            <?php
                                            $sql = "select * From co_operative";
                                            $result = mysqli_query($con, $sql);
                                            while ($row_ah = mysqli_fetch_assoc($result)) {
                                                ?>
                                                <option value="<?php echo $row_ah['Co_Id']; ?> " id="namesid" name="namesid"><?php echo $row_ah['Co_Name']; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Distributor Name:</b> 
                                    <div class="form-group mx-sm-5 mb-2 px-3">
                                        <select class=" " name="editdisname" id='editdisname'selected="selected" required >
                                            <option value="" selected="selected" disabled >--- Select Distributor---</option>
                                            <?php
                                            $sql1 = "select * From distributor";
                                            $result1 = mysqli_query($con, $sql1);
                                            while ($row_ah1 = mysqli_fetch_assoc($result1)) {
                                                ?>
                                                <option value="<?php echo $row_ah1['Distributor_ID']; ?> " id="namesid" name="namesid"><?php echo $row_ah1['Distributor_Name']; ?></option>
                                            <?php } ?>
                                        </select>

                                    </div>
                                </div>
                            </div>          

                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>Milk Type:</b> 
                                    <div class="form-group mx-sm-5 mb-2 px-3 margin3">
                                        <select class=" " name="editmilktype" id='editmilktype'selected="selected" style="margin-left:32%; " required>
                                            <option value="" selected="selected" disabled>--- Select MilkType---</option>     
                                            <option value="Orange"  >Orange</option> 
                                            <option value="Blue"  >Blue</option>  
                                            <option value="Green"  >Green</option>     



                                        </select>

                                    </div>
                                </div>
                            </div>          

                            <input type="text" name="ID" id="ID" hidden>


                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Quantity   :</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2"  >
                                    <input type="text" class="form-control " style="margin-left:33%;"    id="editquantity" name="editquantity" placeholder="Quantity"required>

                                </div>
                            </div>



                            <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 30%; margin-top: 3%" name="Update" type="submit">Update</button>
                        </div></div></div>
            </div>

        </form>
        <!--###########################################################-->

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>

        <script type="text/javascript"  >

            function Delete(id) {
                if (confirm('Are you sure?')) {
                    $.ajax({
                        type: "POST",
                        url: "../DistributorMapping/DeleteDistributorMapping.php",

                        data: {id: id},

                        timeout: 10000,
                        success: function () {
                            document.location.reload()

                        }
                    });
                } else {
                    // Do nothing!

                }
            }


        </script>
        <script>

            function Update(id) {

                $.ajax({
                    type: "POST",
                    url: "../DistributorMapping/UpdateDistributorMapping.php",

                    data: {id: id},
                    datatype: 'json',
                    timeout: 10000,
                    success: function (data) {

                        var arr = new Array();
                        arr = JSON.parse(data);
                        $('#ID').val(arr.Provides_ID);

                        $('#editconame').val(arr.Co_Name);
                        $('#editdisname').val(arr.Distributor_Name);
                        $('#editmilktype').val(arr.Pr_MilkType);
                        $('#editquantity').val(arr.Pr_quantity);


                    }
                });
            }
        </script>
    </body>
</html>