<?php

include('../Database_Connection/Dbconnect.php');

$id = $_POST['id'];
echo $id;
$delete = mysqli_query($con, "DELETE FROM distributor WHERE Distributor_ID='$id'");
?>