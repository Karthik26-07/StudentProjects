<?php
include('../Database_Connection/Dbconnect.php');
$id = $_POST['id'];

$sqli = "select * from distributor  where Distributor_ID ='$id'";
$data = mysqli_query($con, $sqli);
$result=mysqli_fetch_assoc($data);
echo json_encode($result);