<?php
include('../Admin/navbar.php');
include('../Database_Connection/Dbconnect.php');
?>
<?php
session_start();

//$name_error = $phone_error = $stock_error = "";

if (isset($_POST['Add'])) {
//    if (empty($_POST['distributorname'])) {
//        $name_error = "Distributor Name is Required";
//    } else if (!preg_match("/^[a-zA-Z ]*$/", $_POST["distributorname"])) {
//        $nameErr = "Only alphabets and white space are allowed";
//    } else if (empty($_POST['distributorphone'])) {
//        $phone_error = "Distributor Phone number is  is required";
//    } else if (!preg_match("/^[0-9]*$/", $_POST["distributorphone"])) {
//        $phone_error = "Only numeric value is allowed.";
//    } else if (strlen($_POST["distributorphone"]) != 10) {
//        $phone_error = "Mobile no must contain 10 digits.";
//    } else if (empty($_POST['Stock'])) {
//        $stock_error = "Please insert the stock";
//    } else {



    $Distributor_name = $_POST ['distributorname'];
    $Distributor_Phone = $_POST['distributorphone'];
    $Distributor_Address = $_POST['Address'];

    $Query = "insert into distributor(Distributor_Name,Distributor_Phone,Distributor_Address) values('$Distributor_name','$Distributor_Phone','$Distributor_Address')";
    if ($con->query($Query) === TRUE) {
        echo "<script>alert('Succesfullly Added');</script>";
        echo "<script>window.location.href='../Distributor/AddDistributor.php'</script>";
    } else {
        echo "Error: " . $Query . "<br>" . $con->error;
    }
}
//}
$sql = "select * from distributor";
$result = mysqli_query($con, $sql);
$i = 1;
$row = [];
if ($result->num_rows > 0) {

    $row = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<?php
if (isset($_POST['update'])) {
    include('../Database_Connection/Dbconnect.php');

    $id = $_POST['ID'];

    $editdis_name = $_POST ['editdistributorname'];
    $editdis_Phone = $_POST['editdistributorphone'];
    $editdis_address = $_POST['editaddress'];


    $Update = "update distributor set Distributor_Name='$editdis_name',Distributor_Phone='$editdis_Phone', Distributor_Address='$editdis_address' where Distributor_ID='$id' ";
    if ($con->query($Update) === TRUE) {
        echo "<script>alert('Succesfullly Updated');</script>";
        echo "<script>window.location.href='../Distributor/AddDistributor.php'</script>";
    } else {
        echo "Error: " . $Update . "<br>" . $con->error;
    }
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <title>Distributor Registration</title>
        <style>
            .margin{
                margin-left: 10%;
            }
            .index{
                width: 35%;
                left:7%;

            }
            .margin1{
                margin-left: 23%;
            }
            .margin2{
                margin-left:11%; 
            }
            .error {color: #FF0001;}
            .button{
                margin-left: 10%;
                background-color: #8f02fa; 
                width: 10%;
            }
        </style>
    </head>
    <body>

        <!--##############################################insert Modal#####################################>-->
        <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="modal fade" id="Distributor" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="my-1 " style="margin-left:27%;">
                                <h3><b>Add Distributor</b></h3>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div style="margin-top:5%">
                            <div class="form-inline  ">
                                <div class="form-group mb-2 px-5">
                                    <b> Distibutor Name:</b>

                                </div>
                                <div class="form-group mx-sm-0 mb-2">
                                    <input type="text" class="form-control margin" id="distributorname" name="distributorname"  placeholder="Name"required>

                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Phone Number:</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2">
                                    <input type="number" class="form-control margin2 " id="distributorphone" minlength="10" maxlength="10" name="distributorphone" placeholder="Phonenumber"required>

                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Address:</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2"  style="display:block"  >
                                    <!--<input type="text" class="form-control " style="margin-left:37%;"    id="Address" name="Address" placeholder="Address"required>-->
                                    <textarea class="form-control "  rows="3" class="form-control " style="margin-left:41%;"    id="Address" name="Address" placeholder="Address"required></textarea>
                                </div>
                            </div>



                            <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 35%; margin-top: 3%" name="Add" type="submit">Add</button>
                        </div></div></div>
            </div>

        </form>
        <!--###########################################################################################################-->
        <button type="button" class="btn btn-success button" data-toggle="modal" data-target="#Distributor">

            <i class="fa-home"></i>  Add
        </button>
        <form class=" card stud   shadow-lg p-3  mb-5 bg-white rounded body"style="width: 85%;
              left: 8%;">
            <div class="form-group">
                <table class="table  table-striped table-hover ">
                    <thead>
                        <tr>
                            <th scope=col>S.NO</th>

                            <th scope=col>Distributor Name</th>

                            <th scope=col>Phone Number</th>
                            <th scope=col>Address</th>

                            <th scope=col>Action</th>




                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (!empty($row)) {
                            foreach ($row as $row) {
                                ?>   <tr>   
                                    <td><?php echo $i++ ?> </td>
                                    <td><?php echo $row['Distributor_Name']; ?> </td>
                                    <td><?php echo $row['Distributor_Phone']; ?></td>
                                    <td><?php echo $row['Distributor_Address']; ?> </td>
                                    <td id="<?= $row['Distributor_ID'] ?>"><?php echo '   <button type="button"  onclick="Delete( ' . $row['Distributor_ID'] . ');" class="btn btn-danger" >Delete</button>'; ?>
                                        <?php echo '   <button type="button"  onclick="Update(' . $row['Distributor_ID'] . ');" class="btn btn-success" data-toggle="modal" data-target="#editmodal" >Update</button>'; ?></td>


                                    <?php
                                }
                            }
                            ?>
                        </tr></tbody></table></div></form>
        <!--############################################## Edit Modal#####################################>-->
        <form class=" index my-5   p-3 mb-5 bg-white  body" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="my-1 " style="margin-left:27%;">
                                <h3><b>Edit Distributor</b></h3>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <input type="text" name="ID" id="ID" hidden>

                        <div style="margin-top:5%">
                            <div class="form-inline  ">
                                <div class="form-group mb-2 px-5">
                                    <b> Distibutor Name:</b>

                                </div>
                                <div class="form-group mx-sm-0 mb-2">
                                    <input type="text" class="form-control margin" id="editdistributorname" name="editdistributorname"  placeholder="Name"required>

                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Phone Number:</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2">
                                    <input type="number" class="form-control margin2 " id="editdistributorphone" minlength="10" maxlength="10" name="editdistributorphone" placeholder="Phonenumber"required>

                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group mb-2 px-5">
                                    <b>  Address:</b>

                                </div>
                                <div class="form-group mx-sm-2 mb-2"  style="display:block"    >
                                    <!--<input type="text" class="form-control " style="margin-left:37%;"    id="editaddress" name="editaddress" placeholder="Address"required>-->
                                    <textarea class="form-control "  rows="3" class="form-control " style="margin-left:41%;"    id="editaddress" name="editaddress" placeholder="Address"required></textarea>

                                </div>
                            </div>



                            <button class="btn  my-3  text-white" style="background-color: #8f02fa; width: 30%; margin-left: 35%; margin-top: 3%" name="update" type="submit">Update</button>
                        </div></div></div>
            </div>

        </form>
        <!--###########################################################################################################-->

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>


        <script type="text/javascript"  >

            function Delete(id) {
                if (confirm('Are you sure?')) {
                    $.ajax({
                        type: "POST",
                        url: "../Distributor/DeleteDistributor.php",

                        data: {id: id},

                        timeout: 10000,
                        success: function () {
                            document.location.reload()
                        }
                    });
                } else {
                    // Do nothing!

                }
            }


        </script>
        <script>

            function Update(id) {
                $.ajax({
                    type: "POST",
                    url: "../Distributor/updatedistributor.php",

                    data: {id: id},
                    datatype: 'json',
                    timeout: 10000,
                    success: function (data) {
//alert(data);
                        var arr = new Array();
                        arr = JSON.parse(data);
                        $('#ID').val(arr.Distributor_ID);
                        $('#editdistributorname').val(arr.Distributor_Name);
                        $('#editdistributorphone').val(arr.Distributor_Phone);
                        $('#editaddress').val(arr.Distributor_Address);


                    }
                });
            }
        </script>
    </body>
</html>
