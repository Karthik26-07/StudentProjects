-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 09:09 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `casino_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Accont_id` int(10) UNSIGNED NOT NULL,
  `gameid` int(10) NOT NULL,
  `OwnerId` int(11) NOT NULL,
  `CustomerId` int(11) NOT NULL,
  `Income` varchar(11) NOT NULL DEFAULT '0',
  `Loss` varchar(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Accont_id`, `gameid`, `OwnerId`, `CustomerId`, `Income`, `Loss`) VALUES
(1, 1, 1, 1, '15000', '0');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_Id` int(10) UNSIGNED NOT NULL,
  `ownerid` int(11) NOT NULL,
  `Customer_Name` varchar(50) NOT NULL,
  `Customer_Email` varchar(255) NOT NULL,
  `Customer_Phone` varchar(15) NOT NULL,
  `Customer_Address` varchar(255) NOT NULL,
  `Customer_RegNumber` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_Id`, `ownerid`, `Customer_Name`, `Customer_Email`, `Customer_Phone`, `Customer_Address`, `Customer_RegNumber`) VALUES
(1, 1, 'Kiran', 'erhseh', '1234', 'asrhseh', 'thrt');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `Food_id` int(10) UNSIGNED NOT NULL,
  `Ownerid` int(11) NOT NULL,
  `FoodType` varchar(50) NOT NULL,
  `FoodName` varchar(50) NOT NULL,
  `FoodPrice` varchar(50) NOT NULL,
  `FoodVariety` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gamemapping`
--

CREATE TABLE `gamemapping` (
  `Id` int(10) UNSIGNED NOT NULL,
  `ownerid` int(11) NOT NULL,
  `Customer_id` int(11) NOT NULL,
  `Game_id` int(11) NOT NULL,
  `Amount` varchar(50) NOT NULL,
  `is_latest` varchar(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gamemapping`
--

INSERT INTO `gamemapping` (`Id`, `ownerid`, `Customer_id`, `Game_id`, `Amount`, `is_latest`) VALUES
(1, 1, 1, 1, '15000', '0');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `Game_id` int(10) UNSIGNED NOT NULL,
  `ownerid` int(11) NOT NULL,
  `Gamename` varchar(50) NOT NULL,
  `GameType` varchar(50) NOT NULL,
  `GameRules` varchar(255) NOT NULL,
  `MinAmount` varchar(50) NOT NULL,
  `MaxAmount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`Game_id`, `ownerid`, `Gamename`, `GameType`, `GameRules`, `MinAmount`, `MaxAmount`) VALUES
(1, 1, 'Lotus', 'Group', 'sehrt we', '1000', '100000');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `Owner_Id` int(255) UNSIGNED NOT NULL,
  `Owner_FName` varchar(50) NOT NULL,
  `Owner_MName` varchar(50) NOT NULL,
  `Owner_LName` varchar(50) NOT NULL,
  `Owner_Address` varchar(255) NOT NULL,
  `Owner_Phone` varchar(20) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`Owner_Id`, `Owner_FName`, `Owner_MName`, `Owner_LName`, `Owner_Address`, `Owner_Phone`, `Password`) VALUES
(1, 'Karan', 'k', 'Kumar', 'sdbnsfdh', '1234', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Accont_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_Id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`Food_id`);

--
-- Indexes for table `gamemapping`
--
ALTER TABLE `gamemapping`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`Game_id`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`Owner_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `Accont_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `Food_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamemapping`
--
ALTER TABLE `gamemapping`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `Game_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `owner`
--
ALTER TABLE `owner`
  MODIFY `Owner_Id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
