-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2023 at 08:31 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customerrewardpoint`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(10) UNSIGNED NOT NULL,
  `Manager_id` int(11) NOT NULL,
  `Customer_name` varchar(50) NOT NULL,
  `Customer_Phone` varchar(50) NOT NULL,
  `Customer_Address` varchar(50) NOT NULL,
  `is_enabled` varchar(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `Manager_id`, `Customer_name`, `Customer_Phone`, `Customer_Address`, `is_enabled`) VALUES
(6, 2, 'Karabn', '1234', 'asgdaw', '0'),
(7, 2, 'Pretham', '1234', 'sfbsd', '0'),
(8, 2, 'Chirag', '7338357921', 'Karnataka', '0'),
(9, 2, 'Kumara', '1234567890', 'Karnataka', '1');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `customerrewardpoint` BEFORE INSERT ON `customer` FOR EACH ROW SET NEW.is_enabled=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE `discount` (
  `Discount_Id` int(10) UNSIGNED NOT NULL,
  `Product_Id` int(11) NOT NULL,
  `Percentage` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discount`
--

INSERT INTO `discount` (`Discount_Id`, `Product_Id`, `Percentage`) VALUES
(1, 4, 10),
(2, 5, 10),
(3, 6, 15),
(4, 7, 5);

-- --------------------------------------------------------

--
-- Table structure for table `draftbill`
--

CREATE TABLE `draftbill` (
  `Draft_id` int(10) UNSIGNED NOT NULL,
  `Draft_Product` varchar(50) NOT NULL,
  `Draft_Cost` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Manager_Id` int(10) UNSIGNED NOT NULL,
  `Manager_Name` varchar(50) NOT NULL,
  `Manager_Phone` varchar(15) NOT NULL,
  `Manager_Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Manager_Id`, `Manager_Name`, `Manager_Phone`, `Manager_Password`) VALUES
(1, 'Karan', '1234567890', '1234'),
(2, 'Karthik', '1234', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_id` int(10) UNSIGNED NOT NULL,
  `Product_Name` varchar(50) NOT NULL,
  `Product_Price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_id`, `Product_Name`, `Product_Price`) VALUES
(4, 'candy', '500'),
(5, 'Potato', '30'),
(6, 'Mango', '50'),
(7, 'fish', '100');

-- --------------------------------------------------------

--
-- Table structure for table `reward`
--

CREATE TABLE `reward` (
  `Rewards_id` int(10) UNSIGNED NOT NULL,
  `manager_id` int(11) NOT NULL,
  `Customer_id` int(11) NOT NULL,
  `Rewards_point` int(11) NOT NULL,
  `Rewards_Date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reward`
--

INSERT INTO `reward` (`Rewards_id`, `manager_id`, `Customer_id`, `Rewards_point`, `Rewards_Date`) VALUES
(1, 2, 6, 0, '11 Jan, 2023'),
(2, 2, 7, 0, '11 Jan, 2023'),
(3, 2, 8, 319, '22 Jan, 2023'),
(4, 2, 9, 0, '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`Discount_Id`);

--
-- Indexes for table `draftbill`
--
ALTER TABLE `draftbill`
  ADD PRIMARY KEY (`Draft_id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Manager_Id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_id`);

--
-- Indexes for table `reward`
--
ALTER TABLE `reward`
  ADD PRIMARY KEY (`Rewards_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `discount`
--
ALTER TABLE `discount`
  MODIFY `Discount_Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `draftbill`
--
ALTER TABLE `draftbill`
  MODIFY `Draft_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `Manager_Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reward`
--
ALTER TABLE `reward`
  MODIFY `Rewards_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
