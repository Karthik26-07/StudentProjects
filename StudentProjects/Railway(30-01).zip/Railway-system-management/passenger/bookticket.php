<?php
require_once './passengerNav.php';
session_start();
require_once '../db/db.class.php';
$db = new DB();
$trainno=$_GET["trainno"];
$_SESSION['train']=$_GET["trainno"];

$sql = "select * from classinfo where train_number='$trainno'";
$result = $db->executeSelect($sql);


?>
<!--New ticket Model-->


                <form class="card my-5 container" style ="width:50%;"method="POST" action="passengerAction.php" onsubmit="return validateTicket();">
                    <input type="hidden" id="command" name="command" value="bookticket"/>
                    <input type="hidden" id="com_id" name="com_id" />

                   <h1 ><p class="text-center my-3"><b>Book Ticket</b></p></h1>
                   
                    <div class="form-group">
                        <label for="classtype">Class Type</label><br>
                        <select class="" name="classtype" id='classtype' onchange="myfunction(this.value)" selected="selected" style="width:100%; height:10%;">
    <option value="" selected="selected"  >--Select Class Type--</option>
        <?php
          foreach ($result as $trains) 
        {?>  
    
    <option value="<?php echo $trains['class_id']; ?> " ><?php echo $trains['type']; ?></option>
<?php }?>
    </select>
  
                    </div>
                    <div class="form-group ">
 <div class="form-group">
                        <label for="source">Source Station</label>
                        <input type="mail" class="form-control" id="source" name="source"
                               aria-describedby="emailHelp" placeholder="Source Station">

                    </div>
                    <div class="form-group">
                        <label for="destination">Destination Station</label>
                        <input type="mail" class="form-control" id="destination" name="destination"
                               aria-describedby="emailHelp" placeholder="Destination Station">

                    </div>
                    <div class="form-group">
                        <label for="compartment">Compartment</label>
                        <input type="mail" class="form-control" id="compartment" name="compartment"
                               aria-describedby="emailHelp" placeholder="Compartment">

                    </div>
                    <div class="form-group">
                        <label for="seatno">Seat Number</label>
                        <input type="text" class="form-control" id="seatno" name="seatno"
                               aria-describedby="emailHelp" placeholder="Seat Number">

                    </div>
                     <div class="form-group">
                        <label for="totalamts">Total Amount</label>
                        <input type="mail" class="form-control" id="totalamt" name="totalamt"
                               aria-describedby="emailHelp" placeholder="Total Amount" readonly>

                    </div>
                    
                        
                        <button type="submit" class="btn btn-primary" style="margin-bottom:5%; margin-top:5%; width: 100%;">Confirm </button>
                
                </form>
                <script src="../js/myscript.js" type="text/javascript">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">

function myfunction(str) {
    
    $.ajax({
        type: "GET",
        url: "getfareamount.php",
        datatype:"json",
        data: {id: str},
        success: function (result) {
            var arr = new Array();
            var data = JSON.parse(result);
           
    document.getElementById("totalamt").value =data;


    
            

        }
    });


}
   </script>




</body>
</html>



