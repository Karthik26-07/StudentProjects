/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function validate(){
   var name= document.getElementById("passengername").value;
   var contact= document.getElementById("passengercontact").value;
   var email= document.getElementById("passengeremail").value;
   
   var gender= document.getElementById("passengegender").value;
   var password= document.getElementById("passengerpassword").value;
    if(name == ""){
        alert("Please enter Your Name..");
        return false;
    }
    else if(contact == ""){
        alert("Please enter Your Contact Number..");
        return false;
    }
    else if(email == ""){
        alert("Please enter Your Email ID..");
        return false;
    }
    else if(gender == "-1"){
        alert("Please enter Gender");
        return false;
    }
    else if(password == ""){
        alert("Please enter Password");
        return false;
    }
    return true;
    
}

function validateTrain(){
   var trainnumber= document.getElementById("trainnumber").value;
   var trainname= document.getElementById("trainname").value;
   var source= document.getElementById("source").value;
   
   var destination= document.getElementById("destination").value;
   var starttime= document.getElementById("starttime").value;
   var endtime= document.getElementById("endtime").value;
    if(trainnumber == ""){
        alert("Please enter Train Number..");
        return false;
    }
    else if(trainname == ""){
        alert("Please enter Train Name..");
        return false;
    }
    else if(source == ""){
        alert("Please enter Source Station..");
        return false;
    }
    else if(destination == ""){
        alert("Please enter Destination Station");
        return false;
    }
    else if(starttime == ""){
        alert("Please enter Strat time");
        return false;
    }
    else if(endtime == ""){
        alert("Please enter End time");
        return false;
    }
    return true;
    
}

function validateTrainClass(){
     var trainnumber= document.getElementById("trainnumber").value;
   var classtype= document.getElementById("classtype").value;
   var trainfare= document.getElementById("trainfare").value;
   if(trainnumber == "-1"){
        alert("Please select Train Number..");
        return false;
    }
    else if(classtype == "-1"){
        alert("Please select Class Type..");
        return false;
    }
    else if(trainfare == ""){
        alert("Please enter Train Fare..");
        return false;
    }
    return true;
}
function validatepassengerLogin(){
    var phonenumber= document.getElementById("phone").value;
    var password= document.getElementById("password").value;
  if(phonenumber ==""){
    alert('Please enter the Contact Number');
    return false;

  }else if(password==""){
    alert('Please enter the password');
    return false;
  }
return true;

}


function validateTicket(){
    var classtype= document.getElementById("classtype").value;
    var comartment= document.getElementById("compartment").value;
    var source= document.getElementById("source").value;
    
    var destination= document.getElementById("destination").value;
    var seatno= document.getElementById("seatno").value;

     if(classtype == ""){
         alert("Please select the class type..");
         return false;
     }
    
     else if(source == ""){
         alert("Please enter Source Station..");
         return false;
     }
     else if(destination == ""){
         alert("Please enter Destination Station");
         return false;
     }
     else if(comartment == ""){
        alert("Please enter Compartment..");
        return false;
    }
     else if(seatno == ""){
         alert("Please enter Seat Number");
         return false;
     }
     
     return true;
     
 }

 