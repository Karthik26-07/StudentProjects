<?php

require_once './departmentNav.php';
?>
 
 <form 
                >
                <div class="row justify-content-center ">
                <img src="../Images/Rails.jpg"  alt="Responsive image" width= "100%"
  height= "auto">
            </div>

            
            </form>