-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2023 at 08:09 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patientmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `discharge`
--

CREATE TABLE `discharge` (
  `DischargeId` int(10) UNSIGNED NOT NULL,
  `Dis_patientId` varchar(50) NOT NULL,
  `Dis_Symptom` varchar(50) NOT NULL,
  `Dis_dischargedate` varchar(50) NOT NULL,
  `Dis_covStat` varchar(50) NOT NULL,
  `Dis_covTemp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discharge`
--

INSERT INTO `discharge` (`DischargeId`, `Dis_patientId`, `Dis_Symptom`, `Dis_dischargedate`, `Dis_covStat`, `Dis_covTemp`) VALUES
(1, '14', 'covid', '12 Jan, 2023', 'gwag', 'egwgwe'),
(2, '14', '245', '4 Jan, 2023', 'wge', 'geerwg'),
(3, '15', 'va', '17 Jan, 2023', 'gwag', 'gwag'),
(4, '14', 'dfbhsdhb', '11 Jan, 2023', 'serheh', 'erheh'),
(5, '15', 'sdasg', '18 Jan, 2023', 'dga', 'sdgsa');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `DoctorId` int(10) UNSIGNED NOT NULL,
  `DoctorName` varchar(50) NOT NULL,
  `DoctorEmail` varchar(50) NOT NULL,
  `is_active` varchar(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`DoctorId`, `DoctorName`, `DoctorEmail`, `is_active`) VALUES
(1, 'chethan', 'chethan', '0'),
(2, 'chethan1', 'chethan@gmail.com', '0'),
(3, 'ertye', 'ertuertu', '0'),
(4, 'kiran', 'acvd@gmail.xom', '1');

-- --------------------------------------------------------

--
-- Table structure for table `patientaddmission`
--

CREATE TABLE `patientaddmission` (
  `Adm_Id` int(255) UNSIGNED NOT NULL,
  `Patient_Id` int(50) NOT NULL,
  `Adm_Date` varchar(200) NOT NULL,
  `Adm_Symptoms` varchar(200) NOT NULL,
  `Adm_covStat` varchar(40) NOT NULL,
  `Adm_covTemp` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientaddmission`
--

INSERT INTO `patientaddmission` (`Adm_Id`, `Patient_Id`, `Adm_Date`, `Adm_Symptoms`, `Adm_covStat`, `Adm_covTemp`) VALUES
(24, 14, '17 Jan, 2023', 'feaver', 'normal', '30'),
(25, 15, '5 Jan, 2023', 'dvas', 'asdva', 'dsva'),
(26, 14, '5 Jan, 2023', 'v', 'rge', 'regeg'),
(27, 14, '18 Jan, 2023', 'regeg', 'ergewg', 'regeg'),
(28, 14, '11 Jan, 2023', 'erut', 'erht', 'rtuet');

-- --------------------------------------------------------

--
-- Table structure for table `patient_register`
--

CREATE TABLE `patient_register` (
  `Id` int(255) UNSIGNED NOT NULL,
  `patientName` varchar(255) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(10) NOT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `wardNumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_register`
--

INSERT INTO `patient_register` (`Id`, `patientName`, `Age`, `Gender`, `Address`, `phonenumber`, `wardNumber`) VALUES
(14, 'Karan', '20', 'Male', 'lalbhag', '1234567890', '324'),
(15, 'ryjr', 'yjr', 'Male', 'tyjrt', 'yjrtjy', '324'),
(16, 'rty', 'rtyjr', 'Male', 'ryuru', '1234567890', '35');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_Id` int(10) UNSIGNED NOT NULL,
  `StaffName` varchar(50) NOT NULL,
  `StaffWardNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_Id`, `StaffName`, `StaffWardNo`) VALUES
(2, 'bfds', '324'),
(3, 'jyrrj', '12');

-- --------------------------------------------------------

--
-- Table structure for table `treatedby`
--

CREATE TABLE `treatedby` (
  `treated_Id` int(10) UNSIGNED NOT NULL,
  `Doctor_Id` int(11) NOT NULL,
  `Patient_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatedby`
--

INSERT INTO `treatedby` (`treated_Id`, `Doctor_Id`, `Patient_Id`) VALUES
(1, 2, 14),
(2, 1, 14),
(3, 1, 14),
(4, 1, 14);

-- --------------------------------------------------------

--
-- Table structure for table `ward`
--

CREATE TABLE `ward` (
  `Ward_id` int(10) UNSIGNED NOT NULL,
  `Ward_Number` varchar(50) NOT NULL,
  `NoOfpatients` varchar(10) NOT NULL,
  `WardPhone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ward`
--

INSERT INTO `ward` (`Ward_id`, `Ward_Number`, `NoOfpatients`, `WardPhone`) VALUES
(1, '12', '49', '1234567890'),
(2, '324', '436', '334'),
(3, '35', '547345', '65'),
(4, '12', '43', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `discharge`
--
ALTER TABLE `discharge`
  ADD PRIMARY KEY (`DischargeId`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`DoctorId`);

--
-- Indexes for table `patientaddmission`
--
ALTER TABLE `patientaddmission`
  ADD PRIMARY KEY (`Adm_Id`);

--
-- Indexes for table `patient_register`
--
ALTER TABLE `patient_register`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_Id`);

--
-- Indexes for table `treatedby`
--
ALTER TABLE `treatedby`
  ADD PRIMARY KEY (`treated_Id`);

--
-- Indexes for table `ward`
--
ALTER TABLE `ward`
  ADD PRIMARY KEY (`Ward_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `discharge`
--
ALTER TABLE `discharge`
  MODIFY `DischargeId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `DoctorId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patientaddmission`
--
ALTER TABLE `patientaddmission`
  MODIFY `Adm_Id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `patient_register`
--
ALTER TABLE `patient_register`
  MODIFY `Id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `treatedby`
--
ALTER TABLE `treatedby`
  MODIFY `treated_Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ward`
--
ALTER TABLE `ward`
  MODIFY `Ward_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
